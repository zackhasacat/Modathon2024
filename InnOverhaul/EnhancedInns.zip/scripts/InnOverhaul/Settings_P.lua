local core = require("openmw.core")
local I = require("openmw.interfaces")
local async = require("openmw.async")
local storage = require("openmw.storage")
if (core.API_REVISION < 43) then
    I.Settings.registerPage {
        key = "EnhancedInns",
        l10n = "EnhancedInns",
        name = "Enhanced Inns",
        description = "Enhanced Inns is enabled, but your engine version is too old. Please download a new version of OpenMW Develppment or 0.49+.(Newer than Jan 20, 2024)"
    }
    error("Newer version of OpenMW is required")
end
I.Settings.registerPage {
    key = "EnhancedInns",
    l10n = "EnhancedInns",
    name = "Enhanced Inns",
    description = "Replaced the vanilla Inn mechanic with a dynamic, more useful mechanic."
}
I.Settings.registerGroup {
    key = "SettingsEnhancedInns",
    page = "EnhancedInns",
    l10n = "EnhancedInns",
    name = 'Enhanced inns',
    description = '',
    permanentStorage = true,
    settings = {
        {
            key = "safeSleep",
            renderer = "checkbox",
            name = "Safe Sleep",
            description =
            "If enabled, you will be safe from Assassins and 6th House agents while sleeping in a rented bed with a locked door.",
            default = true
        },
        {
            key = "autoCloseDoor",
            renderer = "checkbox",
            name = "Automatically Close Inn Doors",
            description =
            "If enabled, Inn Doors will close and lock automatically after opened.",
            default = true
        },
        {
            key = "goldPerNight",
            renderer = "number",
            name = "Daily Inn Rate",
            description =
            "Determines the daily fee for Inns",
            default = 10
        },
        {
            key = "goldPerWeek",
            renderer = "number",
            name = "Weekly Inn Rate",
            description =
            "Determines the weekly fee for Inns",
            default = 60
        },
    }
}

local SettingsEnhancedInns = storage.playerSection("SettingsEnhancedInns")

SettingsEnhancedInns:subscribe(async:callback(function(section, key)
    if key then
        core.sendGlobalEvent("SettingsEnhancedInnsUpdate", {value = SettingsEnhancedInns:get(key), key = key})
        
    end
end))