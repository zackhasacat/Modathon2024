local types = require("openmw.types")
local world = require("openmw.world")
local acti = require("openmw.interfaces").Activation
local util = require("openmw.util")
local I = require("openmw.interfaces")
local async = require("openmw.async")
local core = require("openmw.core")
local calendar = require('openmw_aux.calendar')
local storage = require("openmw.storage")

local section = storage.globalSection("SettingsEnhancedInns")

local defaultValues = {
    goldPerNight = 10,
    goldPerWeek = 60,
    safeSleep = true,
    autoCloseDoor = true,
}

local function getSetting(key)
    local setting = section:get(key)

    if setting ~= nil then
        return setting
    end
if  defaultValues[key] then
return  defaultValues[key]
end

end

local function SettingsEnhancedInnsUpdate(data)

    local val = data.value
    local key = data.key
    section:set(key,val)
end
return {
    interfaceName = "ZS_InnOverhaul_Settings",
    interface = {
        getSetting = getSetting,
    },
    engineHandlers = {
    },
    eventHandlers = {
        SettingsEnhancedInnsUpdate = SettingsEnhancedInnsUpdate,
    }
}
